import allure
from playwright.sync_api import Locator, expect

from elements.base_element import BaseElement
from tools.logger import get_logger

logger = get_logger("TEXTAREA")



class Textarea(BaseElement):
    def get_locator(self, nth: int = 0, **kwargs) -> Locator:
        # Получаем локатор textarea
        return super().get_locator(nth, **kwargs).locator('textarea').first

    @property
    def type_of(self) -> str:
        return 'textarea'

    def fill(self, value: str, nth: int = 0, **kwargs):
        step = f'Fill {self.type_of} "{self.name}" to value "{value}"'

        with allure.step(step):
            locator = self.get_locator(nth, **kwargs)
            logger.info(step)
            locator.fill(value)

    def check_have_value(self, value: str, nth: int = 0, **kwargs):
        step = f'Checking {self.type_of} "{self.name}" have value "{value}"'

        with allure.step(step):
            locator = self.get_locator(nth, **kwargs)
            logger.info(step)
            expect(locator).to_have_value(value)